
import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var btnClick: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print(btnClick.setTitle("Click".localized, for: UIControlState.normal))
  
       // btnClick.setTitle(NSLocalizedString("Click", comment: ""), for: UIControlState.normal)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func didTapDone(_ sender: UIButton) {
        
     let alert = UIAlertController.init(title:"TITLE".localized, message: "Hello!!!".localized, preferredStyle: .alert)
      
        // add an action (button)
        alert.addAction(UIAlertAction(title: "OK".localized, style: UIAlertActionStyle.default, handler: nil))
        
        // show the alert
        self.present(alert, animated: true, completion: nil)
 
    }

}

extension String {
    
    var localized: String {
        return NSLocalizedString(self, tableName: nil, bundle: Bundle.main, value: self, comment: "")
 
    }
    
}
